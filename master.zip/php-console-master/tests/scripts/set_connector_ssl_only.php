<?php

PhpConsole\Connector::getInstance()->enableSslOnlyMode();
